﻿namespace WindowsToolBox
{
    internal class NetworkInfoForm
    {
        private string networkInfo;

        public NetworkInfoForm(string networkInfo)
        {
            this.networkInfo = networkInfo;
        }
    }
}