﻿namespace WindowsToolBox
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.OpenCmd = new System.Windows.Forms.Button();
            this.OpenTaskmgr = new System.Windows.Forms.Button();
            this.AboutMe = new System.Windows.Forms.Button();
            this.OpenNotepad = new System.Windows.Forms.Button();
            this.OpenWindowsSettings = new System.Windows.Forms.Button();
            this.OpenControlPatel = new System.Windows.Forms.Button();
            this.hahaha = new System.Windows.Forms.Button();
            this.ShowSystemInfo = new System.Windows.Forms.Button();
            this.Open = new System.Windows.Forms.FlowLayoutPanel();
            this.OpenExplorer = new System.Windows.Forms.Button();
            this.Opencleanmgr = new System.Windows.Forms.Button();
            this.About = new System.Windows.Forms.FlowLayoutPanel();
            this.tiktok = new System.Windows.Forms.Button();
            this.bilibili = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.Open.SuspendLayout();
            this.About.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // OpenCmd
            // 
            resources.ApplyResources(this.OpenCmd, "OpenCmd");
            this.OpenCmd.Name = "OpenCmd";
            this.OpenCmd.UseVisualStyleBackColor = true;
            this.OpenCmd.Click += new System.EventHandler(this.OpenCmd_Click);
            // 
            // OpenTaskmgr
            // 
            resources.ApplyResources(this.OpenTaskmgr, "OpenTaskmgr");
            this.OpenTaskmgr.Name = "OpenTaskmgr";
            this.OpenTaskmgr.UseVisualStyleBackColor = true;
            this.OpenTaskmgr.Click += new System.EventHandler(this.OpenTaskmgr_Click);
            // 
            // AboutMe
            // 
            resources.ApplyResources(this.AboutMe, "AboutMe");
            this.AboutMe.Name = "AboutMe";
            this.AboutMe.UseVisualStyleBackColor = true;
            this.AboutMe.Click += new System.EventHandler(this.AboutMe_Click);
            // 
            // OpenNotepad
            // 
            resources.ApplyResources(this.OpenNotepad, "OpenNotepad");
            this.OpenNotepad.Name = "OpenNotepad";
            this.OpenNotepad.UseVisualStyleBackColor = true;
            this.OpenNotepad.Click += new System.EventHandler(this.OpenNotepad_Click);
            // 
            // OpenWindowsSettings
            // 
            resources.ApplyResources(this.OpenWindowsSettings, "OpenWindowsSettings");
            this.OpenWindowsSettings.Name = "OpenWindowsSettings";
            this.OpenWindowsSettings.UseVisualStyleBackColor = true;
            this.OpenWindowsSettings.Click += new System.EventHandler(this.OpenWindowsSettings_Click);
            // 
            // OpenControlPatel
            // 
            resources.ApplyResources(this.OpenControlPatel, "OpenControlPatel");
            this.OpenControlPatel.Name = "OpenControlPatel";
            this.OpenControlPatel.UseVisualStyleBackColor = true;
            this.OpenControlPatel.Click += new System.EventHandler(this.OpenControlPatel_Click);
            // 
            // hahaha
            // 
            resources.ApplyResources(this.hahaha, "hahaha");
            this.hahaha.Name = "hahaha";
            this.hahaha.UseVisualStyleBackColor = true;
            this.hahaha.Click += new System.EventHandler(this.hahaha_Click);
            // 
            // ShowSystemInfo
            // 
            resources.ApplyResources(this.ShowSystemInfo, "ShowSystemInfo");
            this.ShowSystemInfo.Name = "ShowSystemInfo";
            this.ShowSystemInfo.UseVisualStyleBackColor = true;
            this.ShowSystemInfo.Click += new System.EventHandler(this.ShowSystemInfo_Click);
            // 
            // Open
            // 
            resources.ApplyResources(this.Open, "Open");
            this.Open.Controls.Add(this.OpenCmd);
            this.Open.Controls.Add(this.OpenTaskmgr);
            this.Open.Controls.Add(this.OpenControlPatel);
            this.Open.Controls.Add(this.OpenNotepad);
            this.Open.Controls.Add(this.OpenWindowsSettings);
            this.Open.Controls.Add(this.OpenExplorer);
            this.Open.Controls.Add(this.Opencleanmgr);
            this.Open.Name = "Open";
            // 
            // OpenExplorer
            // 
            resources.ApplyResources(this.OpenExplorer, "OpenExplorer");
            this.OpenExplorer.Name = "OpenExplorer";
            this.OpenExplorer.UseVisualStyleBackColor = true;
            this.OpenExplorer.Click += new System.EventHandler(this.OpenExplorer_Click);
            // 
            // Opencleanmgr
            // 
            resources.ApplyResources(this.Opencleanmgr, "Opencleanmgr");
            this.Opencleanmgr.Name = "Opencleanmgr";
            this.Opencleanmgr.UseVisualStyleBackColor = true;
            this.Opencleanmgr.Click += new System.EventHandler(this.Opencleanmgr_Click);
            // 
            // About
            // 
            resources.ApplyResources(this.About, "About");
            this.About.Controls.Add(this.tiktok);
            this.About.Controls.Add(this.bilibili);
            this.About.Controls.Add(this.hahaha);
            this.About.Controls.Add(this.AboutMe);
            this.About.Name = "About";
            // 
            // tiktok
            // 
            resources.ApplyResources(this.tiktok, "tiktok");
            this.tiktok.Name = "tiktok";
            this.tiktok.UseVisualStyleBackColor = true;
            this.tiktok.Click += new System.EventHandler(this.tiktok_Click);
            // 
            // bilibili
            // 
            resources.ApplyResources(this.bilibili, "bilibili");
            this.bilibili.Name = "bilibili";
            this.bilibili.UseVisualStyleBackColor = true;
            this.bilibili.Click += new System.EventHandler(this.bilibili_Click);
            // 
            // flowLayoutPanel1
            // 
            resources.ApplyResources(this.flowLayoutPanel1, "flowLayoutPanel1");
            this.flowLayoutPanel1.Controls.Add(this.ShowSystemInfo);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.About);
            this.Controls.Add(this.Open);
            this.Name = "Form1";
            this.Open.ResumeLayout(false);
            this.About.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button OpenCmd;
        private System.Windows.Forms.Button OpenTaskmgr;
        private System.Windows.Forms.Button AboutMe;
        private System.Windows.Forms.Button OpenNotepad;
        private System.Windows.Forms.Button OpenWindowsSettings;
        private System.Windows.Forms.Button OpenControlPatel;
        private System.Windows.Forms.Button hahaha;
        private System.Windows.Forms.Button ShowSystemInfo;
        private System.Windows.Forms.FlowLayoutPanel Open;
        private System.Windows.Forms.FlowLayoutPanel About;
        private System.Windows.Forms.Button OpenExplorer;
        private System.Windows.Forms.Button Opencleanmgr;
        private System.Windows.Forms.Button bilibili;
        private System.Windows.Forms.Button tiktok;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
    }
}

